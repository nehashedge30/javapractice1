package com.demo.beans;


	public class Book {
		private int bId;
		private String bname;
		private String author_name;
		private int qty;
		private int price;
		private int cid;
		public Book() {
			super();
		}
		
		public Book(int bId, String bname, String author_name, int qty, int price, int cid) {
			super();
			this.bId = bId;
			this.bname = bname;
			this.author_name = author_name;
			this.qty = qty;
			this.price = price;
			this.cid = cid;
		}

		public int getbId() {
			return bId;
		}

		public void setbId(int bId) {
			this.bId = bId;
		}

		public String getBname() {
			return bname;
		}

		public void setBname(String bname) {
			this.bname = bname;
		}

		public String getAuthor_name() {
			return author_name;
		}

		public void setAuthor_name(String author_name) {
			this.author_name = author_name;
		}

		public int getQty() {
			return qty;
		}

		public void setQty(int qty) {
			this.qty = qty;
		}

		public int getPrice() {
			return price;
		}

		public void setPrice(int price) {
			this.price = price;
		}

		public int getCid() {
			return cid;
		}

		public void setCid(int cid) {
			this.cid = cid;
		}

		@Override
		public String toString() {
			return "Book [bId=" + bId + ", bname=" + bname + ", author_name=" + author_name + ", qty=" + qty
					+ ", price=" + price + ", cid=" + cid + "]";
		}
	
		
		
	}
