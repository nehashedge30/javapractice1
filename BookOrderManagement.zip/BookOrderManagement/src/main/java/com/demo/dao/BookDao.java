package com.demo.dao;

import java.util.List;

import com.demo.beans.Book;
import com.demo.beans.Category;

public interface BookDao {

	List<Book> findByCid(int cid);

	List<Category> findAllCategory();

	Book findById(int bid);



}
