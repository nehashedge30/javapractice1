package com.demo.services;

import java.util.List;

import com.demo.beans.Book;
import com.demo.beans.Category;
import com.demo.dao.BookDao;
import com.demo.dao.BookDaoImpl;

public class BookServiceImpl implements BookService{
	BookDao bdao;
	public BookServiceImpl() {
		super();
		this.bdao = new BookDaoImpl();
	}
	@Override
	public List<Book> getBookByCId(int cid) {
		return bdao.findByCid(cid);
	}
	@Override
	public List<Category> getAllCategory() {
		return bdao.findAllCategory();
	}
	@Override
	public Book getById(int bid) {
		// TODO Auto-generated method stub
		return bdao.findById(bid);
	}

}
