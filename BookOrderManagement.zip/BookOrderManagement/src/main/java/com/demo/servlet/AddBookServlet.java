package com.demo.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.demo.beans.Book;
import com.demo.beans.CartItem;
import com.demo.services.*;

@WebServlet(name = "AddOrShowCart", urlPatterns = { "/addToCart" })
public class AddBookServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String btn=request.getParameter("btn");
		switch(btn)
		{
			case "add":
				HttpSession sess=request.getSession();
				List<CartItem> clist = (List<CartItem>) sess.getAttribute("cart");
				
				if (clist == null) {
					clist = new ArrayList<>();
				}
				String[] parr = request.getParameterValues("book");
				BookService pservice = new BookServiceImpl();
				for (String id : parr) {
					Book b1 = pservice.getById(Integer.parseInt(id));
					
					int ordQty = Integer.parseInt(request.getParameter("p" + id));
					if (b1.getQty() > ordQty) {
						CartItem c = new CartItem(b1.getbId(), b1.getBname(), ordQty, b1.getPrice());
						clist.add(c);
					} else {
						CartItem c = new CartItem(b1.getbId(), b1.getBname(), ordQty, b1.getPrice());
						clist.add(c);
					}
				}
				System.out.println(clist);
				sess.setAttribute("cart", clist);
				RequestDispatcher rd = request.getRequestDispatcher("categories");
				rd.forward(request, response);
				break;

			case "show":
				rd = request.getRequestDispatcher("showart.jsp");
				rd.forward(request, response);
				break;
			}
	}

}
