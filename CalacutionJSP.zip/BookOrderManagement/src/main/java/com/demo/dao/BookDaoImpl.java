package com.demo.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.demo.beans.Book;
import com.demo.beans.Category;

;

public class BookDaoImpl implements BookDao {
	static Connection conn;
	static PreparedStatement selCategory,selBooks,selById;
	static {
		try {
			conn=DBUtil.getMyConnection();
			
			selCategory=conn.prepareStatement("select * from category1");
			selBooks=conn.prepareStatement("select * from Book where cid=?");
			selById=conn.prepareStatement("select * from Book where bid=?");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@Override
	public List<Book> findByCid(int cid) {
		List<Book> blist = new ArrayList<>();
		try
		{
			selBooks.setInt(1, cid);
			ResultSet rs= selBooks.executeQuery();
			while(rs.next())
			{
				blist.add(new Book(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getInt(4),rs.getInt(5),rs.getInt(6)));
			}
			if(blist.size()>0)
			{
				return blist;
			}
		}
			catch (SQLException e) {
				e.printStackTrace();
		}
		return null;
		
	}
	@Override
	public List<Category> findAllCategory() {
		List<Category> clist = new ArrayList<>();
		try {
			ResultSet rs= selCategory.executeQuery();
			while(rs.next())
			{
				clist.add(new Category(rs.getInt(1),rs.getString(2),rs.getString(3)));
			}
			if(clist.size()>0)
			{
				return clist;
			}
		}catch (SQLException e) {
			e.printStackTrace();
	}
		return null;
	}
	@Override
	public Book findById(int bid) {
		try {
			selById.setInt(1, bid);
			ResultSet rs=selById.executeQuery();
			if(rs.next()) {
				return new Book(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getInt(4),rs.getInt(5),rs.getInt(6));
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return null;
	
	}
}
