package com.demo.dao;

import com.demo.beans.MyUser;

public interface LoginDao {

	MyUser isAuthenticate(String username, String password);
}
