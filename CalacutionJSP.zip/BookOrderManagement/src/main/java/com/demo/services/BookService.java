package com.demo.services;

import java.util.List;

import com.demo.beans.Book;
import com.demo.beans.Category;

public interface BookService {

	List<Book> getBookByCId(int cid);

	List<Category> getAllCategory();

	Book getById(int parseInt);
	
	

}
