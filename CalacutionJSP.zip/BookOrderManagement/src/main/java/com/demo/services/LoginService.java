package com.demo.services;
import com.demo.beans.MyUser;

public interface LoginService {

	MyUser isValidate(String username, String password);
}
