package com.demo.services;

import com.demo.beans.MyUser;

import com.demo.dao.LoginDao;
import com.demo.dao.LoginDaoImpl;

public class LoginServiceImpl implements LoginService {
	LoginDao ldao;

	public LoginServiceImpl() {
		super();
		ldao = new LoginDaoImpl();
	}

	@Override
	public MyUser isValidate(String username, String password) {
		// TODO Auto-generated method stub
		return ldao.isAuthenticate(username,password);
	}


	


}
