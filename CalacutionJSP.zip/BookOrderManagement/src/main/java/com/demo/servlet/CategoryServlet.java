package com.demo.servlet;

import java.io.IOException;

import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.demo.beans.Category;
import com.demo.services.BookService;
import com.demo.services.BookServiceImpl;


@WebServlet("/categories")
public class CategoryServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

 
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		BookService bservice=new BookServiceImpl();
		List<Category> clist=bservice.getAllCategory();
		request.setAttribute("clist",clist);
		RequestDispatcher rd= request.getRequestDispatcher("categoryPage.jsp");
		rd.forward(request, response);	
	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		doPost(request, response);
	}
	
}
